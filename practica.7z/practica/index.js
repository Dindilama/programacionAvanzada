const express = require('express');
const bodyParser = require('body-parser'); // Trabajar req.body
// La siguiente instrucción permite tomar el contenido de 
// de una vable de entorno y sino la encuentra, toma el puerto 3500
const port = process.env.PORT || 3500

const app = express();
// middleware para tomar datos procedentes de un form
app.use(bodyParser.urlencoded({ extended: true }));
// middleware para tomar datos procedentes de json
app.use(bodyParser.json());

let vehiculos = [
    {nroplaca:'TRJ123',marca:'Mazda CX 5',modelo:'2020', precio:50,estado:true},
    {nroplaca:'ABC789',marca:'Chevrolet Tracker',modelo:'2022', precio:45,estado:false},
];
let state = true
// Middleware para tomar controlar el flujo de funciones en el servidor
app.use((req, res, next) => {
    if (state) {
        next();
    }
    else{
        //next(new Error("No tiene acceso al aplicativo ..."))
        res.send("No tiene acceso al aplicativo ...")
    }
})
let myplate= "TRJ123"
app.use((req, res, next)=>{
    let sveh = vehiculos.find( vh => vh.nroplaca === myplate);
    if (sveh) {
        next();
    }
    else{
        res.send("Eres un intruso ...")
    }

})



app.get('/vehiculos', (req, res)=>{
    res.json(vehiculos)
})

app.get('/', (req, res)=>{
    res.send("Inicio")
})

app.get('/vehxplaca/:nroplaca',(req, res)=>{
    let searchVehiculo = vehiculos.find(veh => veh.nroplaca === req.params.nroplaca);
    if (searchVehiculo){ // lo encuentra
        res.json(searchVehiculo)
    }
    else{
        res.json({message:'Nro placa no existe'})
    }
})

app.get('/vehxplacaf',(req, res)=>{
    let sVeh = vehiculos.find( vh => vh.nroplaca === req.body.nroplaca);
    if (sVeh){
        res.json(sVeh)
    }
    else{
        res.json({message:'Nro placa no existe'})
    }
})

app.post('/vehiculos',(req, res)=>{
    let sVeh = vehiculos.find( vh => vh.nroplaca === req.body.nroplaca);
    if (!sVeh){
        vehiculos.push(req.body);
        res.end()
    }
    else{
        res.json({message:'Nro placa Existe. Inténtelo con otra...'})
    }
})

app.put('/vehiculos',(req, res)=>{
    let index = vehiculos.findIndex(vh => vh.nroplaca === req.body.nroplaca);
    if (index != -1){
        vehiculos[index] = req.body
        res.end()
    }
    else{
        res.json({message:'Nro placa no existe ...'})
    }
})

app.delete('/vehiculos/:nroplaca',(req, res)=>{
    let index = vehiculos.findIndex(vh => vh.nroplaca === req.params.nroplaca);
    if (index != -1){
        vehiculos.splice(index,1);
        res.end();
    }
    else{
        res.json({message:'Nro placa NO existe ...'})
    }
})

app.listen(port, ()=>{
    console.log(`Server in http://localhost:${port}`)
})